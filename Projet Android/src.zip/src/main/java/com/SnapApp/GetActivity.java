package com.SnapApp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.SnapApp.model.Snap;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by walpita on 17/11/17.
 */

public class GetActivity extends AppCompatActivity {

    private ImageView imageViewGet;
    private TextView textViewGet;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get);
        imageViewGet = findViewById(R.id.imageViewGet);
        Bundle extras = getIntent().getExtras();
        textViewGet = findViewById(R.id.textViewGet);

        if(extras != null && extras.getString("ImageSnap") != null ) {
            String encodedImage = extras.getString("ImageSnap");
            String text = extras.getString("TextSnap");;
            byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            imageViewGet.setImageBitmap(decodedByte);
            Log.i("mySNAP", "TextSnap in " + text);
            textViewGet.setText(text);
            Log.i("mySNAP", "Show SNAP");
        }
    }
}
