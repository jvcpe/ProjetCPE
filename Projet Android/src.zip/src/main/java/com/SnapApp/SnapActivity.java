package com.SnapApp;

import android.Manifest;
import android.app.AlertDialog;;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.SnapApp.model.Snap;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.SnapApp.MainActivity.MY_PERMISSIONS_REQUEST_LOCATION;

public class SnapActivity extends AppCompatActivity {

    static final int REQUEST_TAKE_PHOTO = 1;
    String mCurrentPhotoPath;
    private StorageReference mStorage;
    private Button buttonCamera;
    private Button buttonGallery;
    private Button buttonSend;
    private ImageView imageView;
    private TextView textView;
    private boolean imageHere = false;
    private static final int GALLERY_INTENT = 2;
    private DatabaseReference databaseSnap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_snap);

        mStorage = FirebaseStorage.getInstance().getReference();
        databaseSnap = FirebaseDatabase.getInstance().getReference("Snap");

        buttonCamera = findViewById(R.id.buttonCamera);
        buttonGallery = findViewById(R.id.buttonGallery);
        buttonSend = findViewById(R.id.buttonSend);
        imageView = findViewById(R.id.imageView);
        textView = findViewById(R.id.textView);
        textView.setImeOptions(EditorInfo.IME_ACTION_DONE);
        textView.setSingleLine(true);

        buttonCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkCameraPermission()) {
                    dispatchTakePictureIntent();
                }
            }

        });

        buttonGallery.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(checkExternalStoragePermission()) {


                    Intent intent = new Intent(Intent.ACTION_PICK);
                    intent.setType("image/*");
                    startActivityForResult(intent, GALLERY_INTENT);
                }
            }
        });

        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(imageHere == true){
                    //SendImage();
                    addSnap();
                }
                else{
                    Toast.makeText(SnapActivity.this, "Pas de photo a envoye", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent Data){
        super.onActivityResult(requestCode,resultCode,Data);

        if(requestCode == GALLERY_INTENT && resultCode == RESULT_OK){

            Uri uri = Data.getData();
            imageView.setImageURI(uri);
            imageHere = true;
            mCurrentPhotoPath = getRealPathFromURI(uri);
        }

        if(requestCode == REQUEST_TAKE_PHOTO && resultCode == RESULT_OK){

            Bitmap bitmap = BitmapFactory.decodeFile(mCurrentPhotoPath);
            imageView.setImageBitmap(bitmap);
            imageHere = true;
        }

    }

    public String getRealPathFromURI(Uri uri) {
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        cursor.moveToFirst();
        int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
        return cursor.getString(idx);
    }

    private void dispatchTakePictureIntent() {
        Log.i("mySNAP", "take picture intent");
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.example.android.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                galleryAddPic();
                startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);

            }
        }
    }

    public boolean checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    android.Manifest.permission.CAMERA)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle(R.string.title_location_permission)
                        .setMessage(R.string.text_location_permission)
                        .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(SnapActivity.this,
                                        new String[]{android.Manifest.permission.CAMERA},1);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.CAMERA},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }

    private File createImageFile() throws IOException {
        Log.i("mySNAP", "create Image File");
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        Log.i("mySNAP", storageDir.toString());
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        Log.i("mySNAP", mCurrentPhotoPath);
        Log.i("mySNAP", image.toString());
        return image;
    }

    private void galleryAddPic() {
        Log.i("mySNAP", "addPic");
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        File f = new File(mCurrentPhotoPath);
        Uri contentUri = Uri.fromFile(f);
        mediaScanIntent.setData(contentUri);
        this.sendBroadcast(mediaScanIntent);
    }

    private void SendImage(){
        File f = new File(mCurrentPhotoPath);
        Uri contentUri = Uri.fromFile(f);
        StorageReference SR = mStorage.child("Image").child(contentUri.getLastPathSegment());
        SR.putFile(contentUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Toast.makeText(SnapActivity.this, "Upload Done.", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void addSnap(){

        double longitude = 100;
        double latitude = 100;

        longitude = Double.parseDouble(getIntent().getStringExtra("LONG"));
        latitude = Double.parseDouble(getIntent().getStringExtra("LAT"));

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        Bitmap bitmap = BitmapFactory.decodeFile(mCurrentPhotoPath);
        bitmap.compress(Bitmap.CompressFormat.JPEG, 10, stream);
        byte[] byteFormat = stream.toByteArray();

        String encodedImage = Base64.encodeToString(byteFormat, Base64.NO_WRAP);
        String text = textView.getText().toString();

        if(longitude == 100 || latitude == 100 || encodedImage == ""){
            Toast.makeText(this, "Pas rempli", Toast.LENGTH_LONG).show();
        }else{
            String id = databaseSnap.push().getKey();
            Snap snap = new Snap(id, longitude, latitude, encodedImage, text);
            try{
                databaseSnap.child(id).setValue(snap);
                Toast.makeText(this, "Snap Uploaded", Toast.LENGTH_LONG).show();
            }catch (Exception e){
                Toast.makeText(this, "Snap Upload Failed", Toast.LENGTH_LONG).show();

            }

        }
    }

    public boolean checkExternalStoragePermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    android.Manifest.permission.READ_EXTERNAL_STORAGE)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle(R.string.title_location_permission)
                        .setMessage(R.string.text_location_permission)
                        .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(SnapActivity.this,
                                        new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE},1);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }
}
