package com.SnapApp.model;

import com.google.firebase.database.IgnoreExtraProperties;

import static java.lang.Math.abs;
import static java.lang.Math.sqrt;

@IgnoreExtraProperties
public class Snap {
    private String id;
    private String imageEncoded;
    private double longitude;
    private double latitude;
    private String text;
    private double multi;

    public Snap() {

    }

    public Snap(String id, double longitude, double latitude, String imageEncoded, String text) {
        this.longitude = longitude;
        this.latitude = latitude;
        this.id = id;
        this.imageEncoded = imageEncoded;
        this.text = text;
        this.multi= abs(longitude * latitude);
    }

    public double getLongitude() {
        return longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public String getImageEncoded(){
        return imageEncoded;
    }

    public String getText(){
        return text;
    }

    public double getMulti() {
        return multi;
    }
}