package com.SnapApp;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.SnapApp.model.Snap;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.tasks.Task;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import com.mapbox.mapboxsdk.Mapbox;
import com.mapbox.mapboxsdk.annotations.Marker;
import com.mapbox.mapboxsdk.annotations.MarkerOptions;
import com.mapbox.mapboxsdk.annotations.MarkerViewOptions;
import com.mapbox.mapboxsdk.geometry.LatLng;
import com.mapbox.mapboxsdk.maps.MapView;
import com.mapbox.mapboxsdk.maps.MapboxMap;
import com.mapbox.mapboxsdk.maps.OnMapReadyCallback;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import timber.log.Timber;

public class MainActivity extends AppCompatActivity implements
        GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, com.google.android.gms.location.LocationListener {

    private MapView mapView;
    private GoogleApiClient mGoogleApiClient;
    private Location mLastLocation;
    private Boolean mRequestingLocationUpdates = true;
    private LocationRequest mLocationRequest;
    private Marker marker;
    private Button buttonSnap;
    private List<Snap> snaps = new ArrayList<>();
    private List<Snap> tempsnaps = new ArrayList<>();
    private MapboxMap myMapBoxMap;
    private boolean wait = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        init(savedInstanceState);

        buttonSnap = (Button) findViewById(R.id.buttonSnap);
        buttonSnap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("mySNAP", "SNAPBUTTON on click");
                Intent intent = new Intent(MainActivity.this, SnapActivity.class);
                intent.putExtra("LONG", String.valueOf(mLastLocation.getLongitude()));
                intent.putExtra("LAT", String.valueOf(mLastLocation.getLatitude()));
                startActivity(intent);
                           }
        });
    }

    private void init(Bundle savedInstanceState){

        Mapbox.getInstance(this, BuildConfig.MAP_BOX_TOKEN);
        setContentView(R.layout.activity_main);
        mapView = findViewById(R.id.mapView);
        mapView.setStyleUrl("https://tile.jawg.io/jawg-streets.json?access-token=" + BuildConfig.JAWG_API_KEY);
        mapView.onCreate(savedInstanceState);

        mapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(MapboxMap mapboxMap) {
                myMapBoxMap = mapboxMap;
                if(checkLocationPermission()){
                    if(mLastLocation == null ){
                        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
                    }
                }
                //Icon icon = IconFactory.getInstance(MainActivity.this).fromResource(R.drawable.purple_marker);
                marker = mapboxMap.addMarker(new MarkerOptions()
                        .position(new LatLng(mLastLocation.getLatitude(),mLastLocation.getLongitude()))
                        .title("You are Here")
                );
                //marker.showInfoWindow(mapboxMap,mapView);

                mapboxMap.getMarkerViewManager().setOnMarkerViewClickListener(new MapboxMap.OnMarkerViewClickListener() {
                    @Override
                    public boolean onMarkerClick(@NonNull Marker marker, @NonNull View view, @NonNull MapboxMap.MarkerViewAdapter adapter) {
                        Timber.e(marker.toString());
                        Log.i("mySNAP", "click on marker");
                        Snap mySnap = null;
                        for(Snap tempSnap : snaps){
                            if(tempSnap.getLatitude() == marker.getPosition().getLatitude()
                                    && tempSnap.getLongitude() == marker.getPosition().getLongitude()){
                               mySnap = tempSnap;
                            }
                        }

                        Intent intent = new Intent(MainActivity.this, GetActivity.class);
                        intent.putExtra("ImageSnap",mySnap.getImageEncoded() );
                        intent.putExtra("TextSnap",mySnap.getText() );
                        Log.i("mySNAP", "TextSnap out " + mySnap.getText());
                        startActivity(intent);
                        return false;
                    }
                });

                if(!wait) {
                    GetMarkersCoordFromSingleCoord(mLastLocation.getLatitude(),
                            mLastLocation.getLongitude(), 10.0);
                    Log.i("mySNAP", "snaps retrieving");
                }

            }
        });

        //Timer for auto refresh
        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if(mLastLocation != null) {
                    GetMarkersCoordFromSingleCoord(mLastLocation.getLatitude(),
                            mLastLocation.getLongitude(), 1000.0);
                    Log.i("mySNAP", "snaps retrieving Interval");
                }
            }
        },0,15000);

        if (mGoogleApiClient == null) {
            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .addApi(LocationServices.API)
                    .build();
        }


        createLocationRequest();

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(mLocationRequest);

        Task<LocationSettingsResponse> result =
                LocationServices.getSettingsClient(this).checkLocationSettings(builder.build());

    }
    @Override
    public void onLocationChanged(Location location) {
        mLastLocation = location;
        if(marker != null){
            marker.setPosition(new LatLng(mLastLocation.getLatitude(),mLastLocation.getLongitude()));
        }
    }


    protected void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(10000);
        mLocationRequest.setFastestInterval(5000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    @Override
    public void onConnected(Bundle connectionHint) {
        if(checkLocationPermission()){
            if(mLastLocation == null ){
                mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
            }
            if(mRequestingLocationUpdates) {
                startLocationUpdates();
            }
        }
    }

    protected void startLocationUpdates() {
        if(checkLocationPermission()){
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }


    @Override
    public void onConnectionSuspended(int i) {
    }

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;

    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle(R.string.title_location_permission)
                        .setMessage(R.string.text_location_permission)
                        .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(MainActivity.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }



    @Override public void onStart() {
        super.onStart();
        mGoogleApiClient.connect();
        mapView.onStart();
    }

    @Override public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override public void onStop() {
        super.onStop();
        mGoogleApiClient.disconnect();
        mapView.onStop();
    }

    @Override public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    public void GetMarkersCoordFromSingleCoord(double latitude, double longitude, double rayonKm){
        DatabaseReference databaseSnap = FirebaseDatabase.getInstance().getReference("Snap");
        ArrayList <double[]> returnArray = new ArrayList<>();
        ArrayList snaps = new ArrayList<>();
        final double rayon = rayonKm;
        final double longiOrigin = longitude;
        final double latOrigin = latitude;
        double convLat = 110.574;
        double convLong = 111.320;

        //works for lat and long > 0
        //cercle de X km, 1° lat= 110.574 km, 1° long = 111.320cos(lat) km
        // latmin 30, latmax 50, longmin 3, longmax 5
        double limitLatMax = latitude + rayonKm/convLat;
        double limitLongMax = longitude + ( rayonKm/convLong*Math.cos(latitude) );
        double limitLatMin = latitude - rayonKm/convLat;
        double limitLongMin = longitude - ( rayonKm/convLong*Math.cos(latitude) );
        double multiMax = Math.abs(limitLatMax*limitLongMax);
        double multiMin = Math.abs(limitLatMin*limitLongMin);
        if(multiMax - multiMin < 0.0){
            Log.i("mySNAP", "need to switch : multiMin: " + multiMin + ", multiMax: " + multiMax);
            double multiTemp = multiMax;
            multiMax = multiMin;
            multiMin = multiTemp;
        }
        // 90 250
        Log.i("mySNAP", "multiMin: " + multiMin + ", multiMax: " + multiMax);
        Query query = databaseSnap.orderByChild("multi").startAt(multiMin).endAt(multiMax);

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                wait = true;
                double convLat = 110.574;
                double convLong = 111.320;
                tempsnaps.clear();
                Log.i("mySNAP", "query in");
                if (dataSnapshot.exists()) {
                    Log.i("mySNAP", "query in2");
                    // dataSnapshot is the "issue" node with all children with id 0
                    for (DataSnapshot snapDB : dataSnapshot.getChildren()) {
                        // do something with the individual "issues"
                        Snap snap = snapDB.getValue(Snap.class);
                        double longiO = longiOrigin;
                        double latO = latOrigin;
                        double longi = snap.getLongitude();
                        double lat = snap.getLatitude();
                       // Log.i("mySNAP", "Sanp: " + snap.getMulti());
                        if( ((lat - latO)*(lat - latO)*convLat*convLat )
                                + ((longi - longiO)*(longi - longiO) * convLong*Math.cos(latO)* convLong*Math.cos(latO))
                                < rayon*rayon){
                            //add snap to the list
                            tempsnaps.add(snap);
                         //   Log.i("mySNAP", "Sanp2: " + snap.getMulti());
                        }
                    }
                    SetAllMarkers ();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
        return ;
    }

    public void SetAllMarkers (){

        if(tempsnaps !=null) {
            snaps = tempsnaps;
            for (Marker tempMarker : myMapBoxMap.getMarkers()) {
                if(mLastLocation != null
                        && tempMarker.getPosition().getLatitude() != mLastLocation.getLatitude()
                        && tempMarker.getPosition().getLongitude() != mLastLocation.getLongitude())
                    myMapBoxMap.removeMarker(tempMarker);
            }
            for (Snap tempSnap : snaps) {
                myMapBoxMap.addMarker(new MarkerViewOptions()
                        .position(new LatLng(tempSnap.getLatitude(), tempSnap.getLongitude())));
                Log.i("mySNAP", "SnapFromSingleCoord : " + tempSnap.getLatitude() + ", "
                        + tempSnap.getLongitude() + ", " + tempSnap.getMulti());
            }
        }
        wait = false;
    }
}
